# ✅ TaskifyConsole

**TaskifyConsole** is a simple task management tool written in F#. It runs in the console and allows users to add, list, and mark tasks as completed. Tasks are saved to a local text file (`tasks.txt`) so they persist across runs.

---

## 📌 Features

- Add new tasks with a title
- View all tasks (completed and pending)
- Mark tasks as done
- Data persistence using a text file

---

## 🎯 Motivation

This project was built as part of a programming assignment to demonstrate:
- File I/O in F#
- List and record manipulation
- Basic command-line interaction
- Clean functional programming practices

---

## 🖥️ How to Build and Run

### 🔧 Requirements
- Microsoft Visual Studio (F# Console App)

Made by Végh Nikolasz
